#' Small VDJ GEX matrix (VGM) for function testing purposes
#'
#' @name small_vgm
#' @references R package Platypus : https://doi.org/10.1093/nargab/lqab023
'small_vgm'
