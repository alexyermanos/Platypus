#' Example csv file 1
#'
#' @name Bcell_sequences_example_tree
#' @references R package Platypus : https://doi.org/10.1093/nargab/lqab023
'Bcell_sequences_example_tree'

#' Example csv file 2
#'
#' @name Bcell_tree_2
#' @references R package Platypus:https://doi.org/10.1093/nargab/lqab023
'Bcell_tree_2'

#' Example repertoire for testing and examples
#'
#' @name new
'new'

