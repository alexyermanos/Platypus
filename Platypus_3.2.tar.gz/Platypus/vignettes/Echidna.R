## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Platypus) #All Echidna functions are contained within Platypus v3.1

## -----------------------------------------------------------------------------

class_switch_prob_mus[class_switch_prob_mus>0]<-0
trans_switch_prob_b[trans_switch_prob_b>0]<-0


## -----------------------------------------------------------------------------
naive<-simulate_repertoire(initial.size.of.repertoire = 500,
                              duration.of.evolution = 30,
                              vdj.branch.prob = 0.5,
                              cell.division.prob = c(0.01,0.3),
                              max.cell.number = 5000,
                              max.clonotype.number = 5000,
                              complete.duration=T,
                              clonal.selection =F,
                              death.rate = 0,
                              transcriptome.on = T,
                              SHM.nuc.prob = 0.00001
)

## -----------------------------------------------------------------------------
clonofreq.isotype.plot(naive[[1]], 50, y.limit = 50)

## -----------------------------------------------------------------------------
clonofreq.trans.plot(all.contig.annotations = naive[[1]], top.n = 50, y.limit = 50, trans.names = colnames(trans_switch_prob_b),history =naive[[12]] )

## -----------------------------------------------------------------------------

class_switch_prob_mus[class_switch_prob_mus>0]<-0
class_switch_prob_mus[1,3]<-0.01
class_switch_prob_mus[1,4]<-0.01
class_switch_prob_mus[1,5]<-0.01
class_switch_prob_mus[1,2]<-0.001
class_switch_prob_mus[1,6]<-0.001
class_switch_prob_mus[1,7]<-0.001
class_switch_prob_mus[7,1]<-0.1


trans_switch_prob_b[trans_switch_prob_b>0]<-0
trans_switch_prob_b[1,3]<-0.01
trans_switch_prob_b[1,2]<-0.01
trans_switch_prob_b[2,3]<-0.8
trans_switch_prob_b[3,4]<-0.001
trans_switch_prob_b[4,3]<-0.01

## -----------------------------------------------------------------------------
expanded<-simulate_repertoire(initial.size.of.repertoire = 50,
                               duration.of.evolution = 30,
                               vdj.branch.prob = 0.1,
                               cell.division.prob = c(0.2,0.2,0.5),
                               max.cell.number = 5000,
                               max.clonotype.number = 5000,
                               complete.duration=T,
                               clonal.selection =T,
                               transcriptome.on = T,
                               death.rate = 0,
                               SHM.nuc.prob = 0.00001,
                               sequence.selection.prob = 0.3,
                               transcriptome.switch.selection.dependent = T,
                               class.switch.selection.dependent = T
)

clonofreq.isotype.plot(expanded[[1]],50,y.limit = 750)


## -----------------------------------------------------------------------------
mus_b_h[[1]]<-mus_b_h[[1]][1:50,]
mus_b_l[[1]]<-mus_b_l[[1]][1:30,]

## -----------------------------------------------------------------------------
even<-simulate_repertoire(initial.size.of.repertoire = 5000,
                                duration.of.evolution = 0,
                                vdj.branch.prob = 0,
                                cell.division.prob = c(0,0),
                                max.cell.number = 5000,
                                max.clonotype.number = 5000,
                                complete.duration=F,
                                clonal.selection = F,
                                death.rate = 0,
                                transcriptome.on = F,
                                igraph.on = F
)

## -----------------------------------------------------------------------------
reph<-mus_b_h[[1]][c(1,2),]
repl<-mus_b_l[[1]][c(1),]

mus_b_h[[1]]<-rbind(mus_b_h[[1]],reph[rep(seq_len(nrow(reph)), each = 30), ])
mus_b_l[[1]]<-rbind(mus_b_l[[1]],repl[rep(seq_len(nrow(repl)), each = 20), ])

## -----------------------------------------------------------------------------
naive<-simulate_repertoire(initial.size.of.repertoire = 500,
                              duration.of.evolution = 30,
                              vdj.branch.prob = 0.5,
                              cell.division.prob = c(0.01,0.3),
                              max.cell.number = 5000,
                              max.clonotype.number = 5000,
                              complete.duration=T,
                              clonal.selection =F,
                              death.rate = 0,
                              transcriptome.on = T,
                              SHM.nuc.prob = 0.00001
)

## -----------------------------------------------------------------------------
clonofreq.isotype.plot(naive[[1]], 50, y.limit = 50)

## -----------------------------------------------------------------------------
clonofreq.trans.plot(all.contig.annotations = naive[[1]], top.n = 50, y.limit = 50, trans.names = colnames(trans_switch_prob_b),history =naive[[12]] )

## -----------------------------------------------------------------------------

class_switch_prob_mus[class_switch_prob_mus>0]<-0
class_switch_prob_mus[1,3]<-0.01
class_switch_prob_mus[1,4]<-0.01
class_switch_prob_mus[1,5]<-0.01
class_switch_prob_mus[1,2]<-0.001
class_switch_prob_mus[1,6]<-0.001
class_switch_prob_mus[1,7]<-0.001
class_switch_prob_mus[7,1]<-0.1


trans_switch_prob_b[trans_switch_prob_b>0]<-0
trans_switch_prob_b[1,3]<-0.01
trans_switch_prob_b[1,2]<-0.01
trans_switch_prob_b[2,3]<-0.8
trans_switch_prob_b[3,4]<-0.001
trans_switch_prob_b[4,3]<-0.01

## -----------------------------------------------------------------------------
uneven<-simulate_repertoire(initial.size.of.repertoire = 5000,
                                              duration.of.evolution = 0,
                                              vdj.branch.prob = 0,
                                              cell.division.prob = c(0,0),
                                              max.cell.number = 5000,
                                              max.clonotype.number = 5000,
                                              complete.duration=F,
                                              clonal.selection = F,
                                              death.rate = 0,
                                              transcriptome.on = F,
                                              igraph.on = F
)

## -----------------------------------------------------------------------------
even_vgu_cell<-get.vgu.matrix(even[[1]],"cell")
even_vgu_clone<-get.vgu.matrix(even[[1]],"clone")

head(even_vgu_cell)
head(even_vgu_clone)

## -----------------------------------------------------------------------------
expanded<-simulate_repertoire(initial.size.of.repertoire = 50,
                               duration.of.evolution = 30,
                               vdj.branch.prob = 0.1,
                               cell.division.prob = c(0.2,0.2,0.5),
                               max.cell.number = 5000,
                               max.clonotype.number = 5000,
                               complete.duration=T,
                               clonal.selection =T,
                               transcriptome.on = T,
                               death.rate = 0,
                               SHM.nuc.prob = 0.00001,
                               sequence.selection.prob = 0.3,
                               transcriptome.switch.selection.dependent = T,
                               class.switch.selection.dependent = T
)

clonofreq.isotype.plot(expanded[[1]],50,y.limit = 750)


## -----------------------------------------------------------------------------
mus_b_h[[1]]<-mus_b_h[[1]][1:50,]
mus_b_l[[1]]<-mus_b_l[[1]][1:30,]

